<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Triage Translation</title>

 
</head>

<body>

<h1>Triage Portal User Profile Notification</h1>
<br>
<h2>Your user profile has been suspended by <?php echo e($user -> first_name); ?> <?php echo e($user -> last_name); ?>.</h2>

</body>

</html><?php /**PATH D:\Projects\triage_api\resources\views/mails/sendSuspendBody.blade.php ENDPATH**/ ?>