<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Triage Translation</title>

 
</head>

<body>
<h1>Triage Portal User Password Reset</h1>
<h2>Your password has been reset. Follow the link to create a new password.</h2>
<br>
<a href="http://localhost:4444/#/user-setup/<?php echo e($language); ?>?id=<?php echo e($registrationHash); ?>">Click here to complete password reset.</a>
 

</body>

</html><?php /**PATH D:\Projects\triage_api\resources\views/mails/sendResetBody.blade.php ENDPATH**/ ?>