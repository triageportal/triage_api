<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Triage Translation</title>

 
</head>

<body>

<h1>Triage Portal User Profile Notification</h1>
<br>
<h2>Your user profile has been suspended by {{$user -> first_name}} {{$user -> last_name}}.</h2>

</body>

</html>